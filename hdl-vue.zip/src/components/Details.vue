<template>
	<div>
		<div class="swiper-container">
			<div class="icon" style="height: 0.5rem;background: #000;width: 100%;">
				<a href="http://localhost:8080/#/table"><i class="iconfont sao">&#xe603;</i></a>
				<i class="iconfont fen" style="right: 0.2rem;top: 0.1rem;">&#xe65a;</i>
				<i class="iconfont bx" style="right: 0.5rem;top: 0.1rem;color: #D43D3D;">&#xe630;</i>
			</div>

			<div class="swiper-slide" style="padding-top: 0.5rem;">
				<ul>
					<li>
						<a href="#" class="banner">
							<img src="../assets/images/d1.jpg" />
						</a>
					</li>
				</ul>
			</div>

		</div>
		<div id="main">
			<div class="main-q">
				<h2>汉京店</h2>
				<img src="../assets/images/star_03.jpg">
				<p>四川海底捞餐饮股份有限公司是一家以经营川味火锅为主，融汇各地火锅特色于</p>
				<a href="#">点击展开</a>

			</div>
		</div>
		<div id="ts">
			<div class="ts-q">
				<div class="ml-a">
					<div class="around">
						
						<i class="iconfont">&#xe677;</i>
					</div>
					<a href="http://localhost:8080/#/book"> 排号</a>
				</div>
				<div class="ml-a">
					<div class="around">
						<i class="iconfont">&#xe82b;</i>
					</div>
					<a href="http://localhost:8080/#/stores">外卖</a>
				</div>
				<div class="ml-a">
					<div class="around">
						<i class="iconfont">&#xe6d0;</i>
					</div>
					<a href="#"> 订餐</a>
				</div>
			</div>

		</div>
		<div class="tiao"></div>
		<div class="foot">
			<i class="iconfont">&#xe665;</i>
			<a href="#">写评论</a>
		</div>
	</div>
</template>

<script>
</script>

<style>
	@import "../assets/css/reset.css";
	@import "../assets/css/details.css";
</style>
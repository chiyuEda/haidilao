<template>
	<div class="main">
		<main>
			<ul class="service service-p1">
				<li>
					<a href="#">
						<div class="left">
							<i class="iconfont service_logo">&#xe611;</i>我的订单
						</div>
						<i class="iconfont toRight">&#xe62e;</i>
					</a>
				</li>
				<li>
					<a href="#">
						<div class="left">
							<i class="iconfont service_logo">&#xe600;</i>我的积分
						</div>
						<i class="iconfont toRight">&#xe62e;</i>
					</a>
				</li>
				<li>
					<a href="#">
						<div class="left">
							<i class="iconfont service_logo">&#xe69b;</i>我的卡券
						</div>
						<i class="iconfont toRight">&#xe62e;</i>
					</a>
				</li>
				<li>
					<a href="#">
						<div class="left">
							<i class="iconfont service_logo">&#xe602;</i>免密支付
						</div>
						<i class="iconfont toRight">&#xe62e;</i>
					</a>
				</li>
			</ul>
			<ul class="service service-p2">
				<li>
					<a href="#">
						<div class="left">
							<i class="iconfont service_logo">&#xe65c;</i>积分抽奖
						</div>
						<i class="iconfont toRight">&#xe62e;</i>
					</a>
				</li>
			</ul>
			<ul class="service service-p3">
				<li>
					<a href="#">
						<div class="left">
							<i class="iconfont service_logo">&#xe611;</i>海捞卡
						</div>
						<i class="iconfont toRight">&#xe62e;</i>
					</a>
				</li>
				<li>
					<a href="#">
						<div class="left">
							<i class="iconfont service_logo">&#xe611;</i>AR相机
						</div>
						<i class="iconfont toRight">&#xe62e;</i>
					</a>
				</li>
			</ul>
			<ul class="service service-p4">
				<li>
					<a href="#">
						<div class="left">
							<i class="iconfont service_logo">&#xe611;</i>Hi说说
						</div>
						<i class="iconfont toRight">&#xe62e;</i>
					</a>
				</li>
				<li>
					<a href="#">
						<div class="left">
							<i class="iconfont service_logo">&#xe611;</i>Hi地盘
						</div>
						<i class="iconfont toRight">&#xe62e;</i>
					</a>
				</li>
				<li>
					<a href="#">
						<div class="left">
							<i class="iconfont service_logo">&#xe611;</i>Hi游戏
						</div>
						<i class="iconfont toRight">&#xe62e;</i>
					</a>
				</li>
			</ul>
		</main>
	</div>
</template>

<script>
</script>

<style>
</style>
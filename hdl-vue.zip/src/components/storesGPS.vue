<template>
	<div class="GPS">
		<header>
			<div class="left">
				<a href="#" class="back"><i class="iconfont back">&#xe603;</i></a>
				<div class="GPS">
					<i class="iconfont dingwei">&#xe614;</i>
					<span class="address">深圳市</span>
					<i class="iconfont todown">&#xe604;</i>
				</div>
			</div>
			<p>外送须知</p>
		</header>
		<span id="zw"></span>
		<main>
			<div id="top_content">
				<p class="title-city">历史访问城市</p>
				<div class="city_content clear">
					<a href="#">深圳市</a>
				</div>
				<p class="title-city clear">国内热门城市</p>
				<div class="city_content">
					<a href="#">深圳市</a>
					<a href="#">西安市</a>
					<a href="#">广州市</a>
					<a href="#">武汉市</a>
					<a href="#">成都市</a>
					<a href="#">南京市</a>
				</div>
			</div>
		</main>
		<mt-index-list>
		  <mt-index-section index="A">
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="B">
		    <mt-cell title="Baldwin"></mt-cell>
		    <mt-cell title="Braden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="C">
		    <mt-cell title="caldwin"></mt-cell>
		    <mt-cell title="craden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="Z">
		    <mt-cell title="Zack"></mt-cell>
		    <mt-cell title="Zane"></mt-cell>
		  </mt-index-section>
		  
		  <mt-index-section index="A">
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="B">
		    <mt-cell title="Baldwin"></mt-cell>
		    <mt-cell title="Braden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="C">
		    <mt-cell title="caldwin"></mt-cell>
		    <mt-cell title="craden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="Z">
		    <mt-cell title="Zack"></mt-cell>
		    <mt-cell title="Zane"></mt-cell>
		  </mt-index-section><mt-index-section index="A">
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="B">
		    <mt-cell title="Baldwin"></mt-cell>
		    <mt-cell title="Braden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="C">
		    <mt-cell title="caldwin"></mt-cell>
		    <mt-cell title="craden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="Z">
		    <mt-cell title="Zack"></mt-cell>
		    <mt-cell title="Zane"></mt-cell>
		  </mt-index-section><mt-index-section index="A">
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="B">
		    <mt-cell title="Baldwin"></mt-cell>
		    <mt-cell title="Braden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="C">
		    <mt-cell title="caldwin"></mt-cell>
		    <mt-cell title="craden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="Z">
		    <mt-cell title="Zack"></mt-cell>
		    <mt-cell title="Zane"></mt-cell>
		  </mt-index-section><mt-index-section index="A">
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="B">
		    <mt-cell title="Baldwin"></mt-cell>
		    <mt-cell title="Braden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="C">
		    <mt-cell title="caldwin"></mt-cell>
		    <mt-cell title="craden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="Z">
		    <mt-cell title="Zack"></mt-cell>
		    <mt-cell title="Zane"></mt-cell>
		  </mt-index-section><mt-index-section index="A">
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="B">
		    <mt-cell title="Baldwin"></mt-cell>
		    <mt-cell title="Braden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="C">
		    <mt-cell title="caldwin"></mt-cell>
		    <mt-cell title="craden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="Z">
		    <mt-cell title="Zack"></mt-cell>
		    <mt-cell title="Zane"></mt-cell>
		  </mt-index-section><mt-index-section index="A">
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="B">
		    <mt-cell title="Baldwin"></mt-cell>
		    <mt-cell title="Braden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="C">
		    <mt-cell title="caldwin"></mt-cell>
		    <mt-cell title="craden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="Z">
		    <mt-cell title="Zack"></mt-cell>
		    <mt-cell title="Zane"></mt-cell>
		  </mt-index-section><mt-index-section index="A">
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="B">
		    <mt-cell title="Baldwin"></mt-cell>
		    <mt-cell title="Braden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="C">
		    <mt-cell title="caldwin"></mt-cell>
		    <mt-cell title="craden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="Z">
		    <mt-cell title="Zack"></mt-cell>
		    <mt-cell title="Zane"></mt-cell>
		  </mt-index-section><mt-index-section index="A">
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="B">
		    <mt-cell title="Baldwin"></mt-cell>
		    <mt-cell title="Braden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="C">
		    <mt-cell title="caldwin"></mt-cell>
		    <mt-cell title="craden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="Z">
		    <mt-cell title="Zack"></mt-cell>
		    <mt-cell title="Zane"></mt-cell>
		  </mt-index-section><mt-index-section index="A">
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="B">
		    <mt-cell title="Baldwin"></mt-cell>
		    <mt-cell title="Braden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="C">
		    <mt-cell title="caldwin"></mt-cell>
		    <mt-cell title="craden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="Z">
		    <mt-cell title="Zack"></mt-cell>
		    <mt-cell title="Zane"></mt-cell>
		  </mt-index-section><mt-index-section index="A">
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="B">
		    <mt-cell title="Baldwin"></mt-cell>
		    <mt-cell title="Braden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="C">
		    <mt-cell title="caldwin"></mt-cell>
		    <mt-cell title="craden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="Z">
		    <mt-cell title="Zack"></mt-cell>
		    <mt-cell title="Zane"></mt-cell>
		  </mt-index-section><mt-index-section index="A">
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		    <mt-cell title="深圳市"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="B">
		    <mt-cell title="Baldwin"></mt-cell>
		    <mt-cell title="Braden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="C">
		    <mt-cell title="caldwin"></mt-cell>
		    <mt-cell title="craden"></mt-cell>
		  </mt-index-section>
		  <mt-index-section index="Z">
		    <mt-cell title="Zack"></mt-cell>
		    <mt-cell title="Zane"></mt-cell>
		  </mt-index-section>
		</mt-index-list>
	</div>
</template>

<script>
</script>

<!--<style>
</style>-->
<style scoped>
  @import '../assets/css/reset.css';
  @import '../assets/css/common.css';
  @import '../assets/css/storesGPS.css';
  
</style>


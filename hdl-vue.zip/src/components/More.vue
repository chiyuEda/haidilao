<template>
	<div>更多页面
	<v-footer></v-footer>
	</div>
</template>

<script>
	import Footer from './Footer.vue';
	export default {
  
  data () {
    return {
      
    }
  },
  components:{
  	'v-footer':Footer
  }
}
</script>

<style>
</style>